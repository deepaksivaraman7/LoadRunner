vuser_end()
{

	/* Logout */

	lr_think_time(23);

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("logout_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("thinkingTesterLogo.png", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/img/thinkingTesterLogo.png", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("login.js", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/js/login.js", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "1");

	return 0;
}