vuser_end()
{

	lr_think_time(39);

	web_url("threatListUpdates:fetch", 
		"URL=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch4KDGdvb2dsZWNocm9tZRIOMTIxLjAuNjE2Ny4xNjEaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARCtlRUaAhgLfpV19SIEIAEgAigBGikIARABGhsKDQgBEAYYASIDMDAxMAEQvekNGgIYC67SNCEiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABEPXgDRoCGAuSqvEWIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARC2rwcaAhgLYb6OcyIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ3DcaAhgLwLZjkiIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ_asCGgIYC2EuNgQiBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAcaAhgLYjna-CIEIAEgAigBGicICRABGhkKDQgJEAYYASIDMDAxMAEQIxoCGAuXnkjLIgQgASACKAEaKAgIEA"
		"EaGgoNCAgQBhgBIgMwMDEwARCxFRoCGAv0T3H1IgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARCKjQIaAhgLbUYmqiIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ9K8OGgIYC0Lt3VQiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEIshGgIYC7kwzGAiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t7.inf", 
		LAST);

	/* Out */

	lr_think_time(25);

	web_url("uitestingplayground.com_2", 
		"URL=http://uitestingplayground.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://uitestingplayground.com/dynamicid", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}