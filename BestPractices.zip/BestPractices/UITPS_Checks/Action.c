Action()
{

	/* Dynamic table */

	lr_think_time(25);

	web_url("dynamictable", 
		"URL=http://uitestingplayground.com/dynamictable", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://uitestingplayground.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
