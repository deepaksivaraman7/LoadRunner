vuser_end()
{

	/* Home */

	lr_think_time(14);

	web_url("uitestingplayground.com_2", 
		"URL=http://uitestingplayground.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://uitestingplayground.com/dynamictable", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}